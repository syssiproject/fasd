 const form = document.querySelector('form');
      const emailInput = document.querySelector('#email');
      const subscribeBtn = document.querySelector('#subscribe-btn');

      form.addEventListener('submit', (event) => {
        event.preventDefault();

        // get the email address from the input field
        const email = emailInput.value;

        // save the email to a file on the server
        fetch('/save-email', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email })
        })
        .then(response => {
          if (response.ok) {
            alert('Email saved successfully!');
          } else {
            alert('There was an error saving the email. Please try again later.');
          }
        })
        .catch(error => {
          alert('There was an error saving the email. Please try again later.');
          console.error(error);
        });

        // clear the input field
        emailInput.value = '';
      });